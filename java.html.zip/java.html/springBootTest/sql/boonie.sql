-- ============================================================
-- 离恨烟·烟雨阁（boonie）数据库初始化脚本
-- 项目：springBootTest（后端） + boonie-vue（前端）
-- 数据库：MySQL 8.0，账号 root / 123456
-- 用法：mysql -uroot -p123456 < boonie.sql
-- ============================================================

-- 创建数据库（utf8mb4 支持中文与 emoji）
CREATE DATABASE IF NOT EXISTS `boonie`
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_general_ci;

USE `boonie`;

-- ------------------------------------------------------------
-- 用户表 app_user
-- 对应实体类 com.fenglin.springboottest.entity.User (@TableName("app_user"))
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `app_user`;
CREATE TABLE `app_user` (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `account`     VARCHAR(64)  NOT NULL                COMMENT '登录账号（邮箱或手机号）',
  `password`    VARCHAR(100) NOT NULL                COMMENT '密码（BCrypt 加密存储）',
  `email`       VARCHAR(64)  DEFAULT NULL            COMMENT '邮箱',
  `phone`       VARCHAR(20)  DEFAULT NULL            COMMENT '手机号',
  `nickname`    VARCHAR(64)  DEFAULT NULL            COMMENT '昵称',
  `created_at`  DATETIME     DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`  DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_account` (`account`),
  KEY `idx_email` (`email`),
  KEY `idx_phone` (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
  COMMENT='用户表';

-- ------------------------------------------------------------
-- 种子数据：演示账号
-- 账号 demo@boonie.com，密码 123456（BCrypt 已加密）
-- ------------------------------------------------------------
INSERT INTO `app_user` (`account`, `password`, `email`, `nickname`) VALUES
('demo@boonie.com', '$2a$10$44/5E6LE8QMVfjA5plfxEOP34.sM80Vwga2SMvCYt0ucN2aUZY/Yy', 'demo@boonie.com', '烟雨阁少侠');
