<script setup>
/**
 * 登录 / 注册页
 * 支持 4 种风格的外观（由 App.vue 写在 html 上的 data-style 决定）
 * 已接入 Spring Boot 后端：
 *   登录  POST /api/auth/login
 *   注册  POST /api/auth/send-code + /api/auth/register
 */
import { ref, computed, onMounted, onBeforeUnmount } from 'vue'
import { useRouter } from 'vue-router'

import { useThemeStore } from '@/stores/theme'
import { useUserStore } from '@/stores/user'
import { useTilt } from '@/composables/useTilt'
import { useLoginForm } from '@/composables/useLoginForm'
import { celebrate } from '@/composables/useCelebrate'
import { sendCode, register as apiRegister, login as apiLogin } from '@/api/auth'

const router = useRouter()
const theme = useThemeStore()
const user = useUserStore()

/* ---------------- 表单状态 ---------------- */
const mode = ref('login') // 'login' | 'register'
const account = ref('')
const password = ref('')
const code = ref('')
const remember = ref(false)
const showPassword = ref(false)
const loading = ref(false)
const sending = ref(false)
const countdown = ref(0)
const message = ref('')
const messageType = ref('')
const shaking = ref(false)

const { accountState, accountIcon, passwordState, isAccountValid } = useLoginForm(account, password)

/* ---------------- 卡片 3D 倾斜（仅森林风） ---------------- */
const { el: cardEl, style: cardStyle } = useTilt(8)

/* ---------------- 各风格的品牌与按钮文案 ---------------- */
const BRAND = {
  forest: { title: '熊出没', sub: 'BOONIE BEARS', action: '登 录', divider: '丛林通道' },
  cartoon: { title: '登录乐园', sub: '', action: '登 录 🐾', divider: '— 或用其他方式 —' },
  neon: { title: 'NEON 登录', sub: '', action: '登 录', divider: '— 丛林通道 —' },
  minimal: { title: '登录', sub: '', action: '登 录', divider: '— 或使用以下方式 —' },
}

const brand = computed(() => BRAND[theme.style] ?? BRAND.forest)
const isForest = computed(() => theme.style === 'forest')
const isCartoon = computed(() => theme.style === 'cartoon')

const submitLabel = computed(() => {
  if (loading.value) return mode.value === 'login' ? '登录中…' : '注册中…'
  return mode.value === 'login' ? brand.value.action : '注 册 🌲'
})

/* ---------------- 回填「记住我」 ---------------- */
onMounted(() => {
  const saved = user.restore()
  if (saved) {
    account.value = saved
    remember.value = true
  }
})

/* ---------------- 验证码倒计时 ---------------- */
let timer = null

function startCountdown() {
  countdown.value = 60
  timer = setInterval(() => {
    countdown.value--
    if (countdown.value <= 0) clearInterval(timer)
  }, 1000)
}

onBeforeUnmount(() => timer && clearInterval(timer))

/* ---------------- 交互 ---------------- */
function togglePassword() {
  showPassword.value = !showPassword.value
}

function setMsg(text, type = '') {
  message.value = text
  messageType.value = type
}

function shake() {
  shaking.value = true
  setTimeout(() => (shaking.value = false), 420)
}

/** 切换 登录 / 注册 模式 */
function switchMode(target) {
  if (mode.value === target) return
  mode.value = target
  setMsg('')
}

/** 发送注册验证码 */
async function onSendCode() {
  const acc = account.value.trim()
  if (!isAccountValid(acc)) {
    shake()
    setMsg(isCartoon.value ? '先填好账号再获取验证码哦' : '请先填写正确的账号', 'err')
    return
  }
  sending.value = true
  setMsg('')
  const res = await sendCode(acc)
  sending.value = false
  if (!res.success) {
    shake()
    setMsg(res.message || '验证码发送失败', 'err')
    return
  }
  startCountdown()
  // 演示模式：后端未配置邮箱授权码时会把验证码放在 data 里返回
  if (res.data) {
    code.value = String(res.data)
    setMsg('演示模式：验证码已自动填入（未配置邮箱授权码）', 'ok')
  } else {
    setMsg(res.message || '验证码已发送，请查收', 'ok')
  }
}

/** 提交登录 / 注册 */
async function onSubmit() {
  const acc = account.value.trim()
  const pwd = password.value

  if (!acc || pwd.length < 6) {
    shake()
    setMsg(isCartoon.value ? '检查一下账号或密码哦' : '请检查账号或密码', 'err')
    return
  }
  if (pwd.length > 15) {
    shake()
    setMsg('密码长度不能超过 15 位', 'err')
    return
  }
  if (mode.value === 'register' && !code.value.trim()) {
    shake()
    setMsg(isCartoon.value ? '还需要输入验证码哦' : '请输入邮箱验证码', 'err')
    return
  }

  loading.value = true
  setMsg('')

  try {
    const res =
      mode.value === 'login'
        ? await apiLogin(acc, pwd)
        : await apiRegister(acc, pwd, code.value.trim())

    if (!res.success) {
      loading.value = false
      shake()
      setMsg(res.message || '操作失败，请稍后再试', 'err')
      return
    }

    // 登录 / 注册成功：保存账号与 token
    user.login(acc, remember.value, res.token || '')
    setMsg(mode.value === 'login' ? '登录成功，欢迎来到狗熊岭！' : '注册成功，欢迎加入狗熊岭！', 'ok')
    celebrate(theme.style)
    loading.value = false
    router.push({ name: 'home' })
  } catch {
    loading.value = false
    shake()
    setMsg('网络异常，无法连接服务器', 'err')
  }
}

function onForgot() {
  setMsg(isCartoon.value ? '找管理员帮帮忙' : '请联系管理员重置密码')
}

function onSocial(name) {
  setMsg(`${name} 登录待接入`)
}
</script>

<template>
  <section class="view login active">
    <div class="login-wrap">
      <div
        ref="cardEl"
        class="card"
        :class="{ shake: shaking }"
        :style="isForest ? cardStyle : undefined"
      >
        <div class="brand">
          <div class="emblem">🐻</div>
          <div>
            <h1>{{ mode === 'register' ? '加入狗熊岭' : brand.title }}</h1>
            <p v-if="mode === 'register'">BECOME A FOREST RANGER</p>
            <p v-else-if="brand.sub">{{ brand.sub }}</p>
          </div>
        </div>

        <form novalidate @submit.prevent="onSubmit">
          <div class="field">
            <label for="acc">账号</label>
            <input
              id="acc"
              v-model="account"
              class="input"
              :class="accountState"
              placeholder="手机号 / 邮箱 / 用户名"
              autocomplete="username"
            />
            <span class="icon">{{ accountIcon }}</span>
          </div>

          <div class="field">
            <label for="pwd">密码</label>
            <input
              id="pwd"
              v-model="password"
              class="input"
              :class="passwordState"
              :type="showPassword ? 'text' : 'password'"
              placeholder="请输入密码（6-15 位）"
              autocomplete="current-password"
              maxlength="15"
            />
            <span class="icon" @click="togglePassword">{{ showPassword ? '🙈' : '👁️' }}</span>
          </div>

          <!-- 注册模式：验证码 -->
          <div v-if="mode === 'register'" class="field code-field">
            <label for="code">验证码</label>
            <div class="code-row">
              <input
                id="code"
                v-model="code"
                class="input"
                placeholder="邮箱验证码"
                inputmode="numeric"
                maxlength="6"
              />
              <button
                type="button"
                class="btn code-btn"
                :disabled="sending || countdown > 0"
                @click="onSendCode"
              >
                {{ countdown > 0 ? `${countdown}s` : sending ? '发送中…' : '获取验证码' }}
              </button>
            </div>
          </div>

          <div v-if="mode === 'login'" class="row">
            <label class="remember">
              <input v-model="remember" type="checkbox" /> 记住我
            </label>
            <a href="#" class="link" @click.prevent="onForgot">忘记密码？</a>
          </div>

          <button class="btn primary block" type="submit" :class="{ loading }" :disabled="loading">
            <span v-if="isForest" class="spinner"></span>
            <span>{{ submitLabel }}</span>
          </button>

          <div class="msg" :class="messageType">{{ message }}</div>
        </form>

        <div class="divider">{{ brand.divider }}</div>

        <div class="social">
          <button type="button" @click="onSocial('微信')">🐻 微信</button>
          <button type="button" @click="onSocial('Apple')">🍎 Apple</button>
          <button type="button" @click="onSocial('QQ')">💬 QQ</button>
        </div>

        <p class="foot">
          <template v-if="mode === 'login'">
            还没有账号？<a href="#" class="link" @click.prevent="switchMode('register')"><b>立即注册</b></a>
          </template>
          <template v-else>
            已有账号？<a href="#" class="link" @click.prevent="switchMode('login')"><b>去登录</b></a>
          </template>
        </p>
      </div>
    </div>
  </section>
</template>

<style scoped>
/* 验证码行（登录页原样式未覆盖，局部补充） */
.code-row {
  display: flex;
  gap: 8px;
  align-items: center;
}
.code-row .input {
  flex: 1;
  min-width: 0;
}
.code-btn {
  flex-shrink: 0;
  padding: 9px 14px;
  border-radius: 10px;
  border: 1px solid rgba(127, 209, 255, 0.5);
  background: rgba(31, 78, 121, 0.25);
  color: inherit;
  font-size: 13px;
  cursor: pointer;
  white-space: nowrap;
  transition: opacity 0.2s;
}
.code-btn:hover:not(:disabled) {
  opacity: 0.85;
}
.code-btn:disabled {
  cursor: not-allowed;
  opacity: 0.55;
}
</style>
