<script setup>
/**
 * 登录 / 注册页 · 离恨烟水墨风（立绘分栏版）
 * 布局参考 lihengyan-login/index.html：左侧立绘 + 竖排诗题，右侧登录卡
 * 已接入 Spring Boot 后端：
 *   登录  POST /api/auth/login
 *   注册  GET /api/auth/captcha + POST /api/auth/register（图形验证码）
 */
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'

import { useUserStore } from '@/stores/user'
import { useLoginForm } from '@/composables/useLoginForm'
import { celebrate } from '@/composables/useCelebrate'
import { getCaptcha, register as apiRegister, login as apiLogin } from '@/api/auth'

const router = useRouter()
const user = useUserStore()

/* ---------------- 表单状态 ---------------- */
const mode = ref('login') // 'login' | 'register'
const account = ref('')
const password = ref('')
const code = ref('')
const remember = ref(false)
const showPassword = ref(false)
const loading = ref(false)
const message = ref('')
const messageType = ref('')
const shaking = ref(false)

/* ---------------- 图形验证码 ---------------- */
const captchaImg = ref('')
const captchaKey = ref('')
const captchaLoading = ref(false)

const { accountState, passwordState } = useLoginForm(account, password)

/* ---------------- 品牌文案 ---------------- */
const brand = {
  title: '离 恨 烟',
  sub: '烟 雨 江 湖 · 与 君 同 行',
  action: '登 录',
  divider: '其 他 方 式 登 录',
}

const submitLabel = computed(() => {
  if (loading.value) return mode.value === 'login' ? '登录中…' : '注册中…'
  return mode.value === 'login' ? brand.action : '注 册'
})

/* ---------------- 回填「记住我」 ---------------- */
onMounted(() => {
  const saved = user.restore()
  if (saved) {
    account.value = saved
    remember.value = true
  }
})

/* ---------------- 图形验证码交互 ---------------- */
async function loadCaptcha() {
  captchaLoading.value = true
  const res = await getCaptcha()
  captchaLoading.value = false
  if (!res.success || !res.data) {
    captchaImg.value = ''
    setMsg(res.message || '验证码加载失败，请点击重试', 'err')
    return
  }
  captchaImg.value = res.data.image
  captchaKey.value = res.data.key
  code.value = ''
  setMsg('')
}

/* ---------------- 交互 ---------------- */
function togglePassword() {
  showPassword.value = !showPassword.value
}

function setMsg(text, type = '') {
  message.value = text
  messageType.value = type
}

function shake() {
  shaking.value = true
  setTimeout(() => (shaking.value = false), 420)
}

/** 切换 登录 / 注册 模式（进入注册时加载图形验证码） */
function switchMode(target) {
  if (mode.value === target) return
  mode.value = target
  setMsg('')
  if (target === 'register' && !captchaImg.value) {
    loadCaptcha()
  }
}

/** 提交登录 / 注册 */
async function onSubmit() {
  const acc = account.value.trim()
  const pwd = password.value

  if (!acc || pwd.length < 6) {
    shake()
    setMsg('请检查账号或密码', 'err')
    return
  }
  if (pwd.length > 15) {
    shake()
    setMsg('密码长度不能超过 15 位', 'err')
    return
  }
  if (mode.value === 'register' && !code.value.trim()) {
    shake()
    setMsg('请输入图片中的 4 位验证码', 'err')
    return
  }

  loading.value = true
  setMsg('')

  try {
    const res =
      mode.value === 'login'
        ? await apiLogin(acc, pwd)
        : await apiRegister(acc, pwd, code.value.trim(), captchaKey.value)

    if (!res.success) {
      loading.value = false
      shake()
      setMsg(res.message || '操作失败，请稍后再试', 'err')
      // 验证码一次性使用，失败后自动换一张
      if (mode.value === 'register') loadCaptcha()
      return
    }

    // 登录 / 注册成功：保存账号与 token
    user.login(acc, remember.value, res.token || '')
    setMsg(mode.value === 'login' ? '登录成功，伞下江湖见！' : '注册成功，欢迎入阁！', 'ok')
    celebrate()
    loading.value = false
    router.push({ name: 'home' })
  } catch {
    loading.value = false
    shake()
    setMsg('网络异常，无法连接服务器', 'err')
  }
}

function onForgot() {
  setMsg('请联系阁主重置密码')
}

function onSocial(name) {
  setMsg(`${name} 登录待接入`)
}
</script>

<template>
  <section class="view login-stage">
    <!-- 飘浮烟雾 -->
    <div class="login-mist m1"></div>
    <div class="login-mist m2"></div>
    <div class="login-mist m3"></div>

    <div class="stage">
      <!-- 左：立绘 + 竖排诗题 -->
      <div class="portrait">
        <img src="/lihengyan.jpg" alt="离恨烟" />
        <div class="verse">烟水茫茫·离恨绵绵 <b>伞落惊鸿</b></div>
      </div>

      <!-- 右：登录 / 注册卡 -->
      <div class="panel">
        <div class="card" :class="{ shake: shaking }">
          <span class="corner tl"></span><span class="corner tr"></span>
          <span class="corner bl"></span><span class="corner br"></span>

          <div class="seal seal-mark">离恨烟</div>

          <div class="brand">
            <h1>{{ mode === 'register' ? '入 阁 通 牒' : brand.title }}</h1>
            <p class="sub">{{ mode === 'register' ? 'BECOME A SWORDSMAN' : brand.sub }}</p>
          </div>

          <svg class="brush-divider" width="240" height="14" viewBox="0 0 240 14">
            <path d="M4,8 Q60,2 120,7 T236,6" stroke="#a37f3d" stroke-width="2.4" fill="none" stroke-linecap="round" opacity=".8" />
            <circle cx="120" cy="7" r="2.6" fill="#b3362b" />
          </svg>

          <form novalidate @submit.prevent="onSubmit">
            <div class="field">
              <label for="acc">账 号</label>
              <input
                id="acc"
                v-model="account"
                class="input"
                :class="accountState"
                placeholder="请输入账号 / 侠客名号"
                autocomplete="username"
              />
              <span class="line"></span>
              <svg class="ico" viewBox="0 0 24 24" fill="none" stroke="#3d504b" stroke-width="1.6">
                <circle cx="12" cy="8" r="4" /><path d="M4,20 Q4,14 12,14 Q20,14 20,20" />
              </svg>
            </div>

            <div class="field">
              <label for="pwd">密 码</label>
              <input
                id="pwd"
                v-model="password"
                class="input"
                :class="passwordState"
                :type="showPassword ? 'text' : 'password'"
                placeholder="请输入密码（6-15 位）"
                autocomplete="current-password"
                maxlength="15"
              />
              <span class="line"></span>
              <span class="icon" @click="togglePassword">{{ showPassword ? '🙈' : '👁️' }}</span>
            </div>

            <!-- 注册模式：图形验证码 -->
            <div v-if="mode === 'register'" class="field">
              <label for="code">验 证 码</label>
              <div class="code-row">
                <input
                  id="code"
                  v-model="code"
                  class="input"
                  placeholder="请输入图中 4 位字符"
                  maxlength="4"
                  autocomplete="off"
                />
                <button
                  v-if="!captchaImg"
                  type="button"
                  class="code-btn"
                  :disabled="captchaLoading"
                  @click="loadCaptcha"
                >
                  {{ captchaLoading ? '加载中…' : '获取验证码' }}
                </button>
                <img
                  v-else
                  class="captcha-img"
                  :src="captchaImg"
                  title="看不清？点击刷新"
                  alt="图形验证码"
                  @click="loadCaptcha"
                />
              </div>
              <span class="line"></span>
            </div>

            <div v-if="mode === 'login'" class="row">
              <label class="remember">
                <input v-model="remember" type="checkbox" />
                <span class="checkbox">
                  <svg viewBox="0 0 24 24" fill="none" stroke="#f8f2e4" stroke-width="3.4" stroke-linecap="round">
                    <path d="M4,12 L10,18 L20,6" />
                  </svg>
                </span>
                记住我
              </label>
              <a href="#" class="link" @click.prevent="onForgot">忘记密码？</a>
            </div>

            <button class="btn primary block" type="submit" :class="{ loading }" :disabled="loading">
              <span class="spinner"></span>
              <span>{{ submitLabel }}</span>
            </button>

            <div class="msg" :class="messageType">{{ message }}</div>
          </form>

          <div class="divider">{{ brand.divider }}</div>

          <div class="social">
            <button type="button" title="微信" @click="onSocial('微信')">
              <svg viewBox="0 0 24 24" fill="#4e8d86"><path d="M9.2,4 C5.4,4 2.4,6.6 2.4,9.8 c0,1.8 1,3.5 2.6,4.5 l-0.7,2.1 2.5-1.3 c0.8,0.2 1.6,0.3 2.4,0.3 h0.3 C9.1,14.8 9,14.2 9,13.5 9,10.4 12,8 15.4,8 c0.3,0 0.7,0 1,0.1 C15.7,5.7 12.8,4 9.2,4 Z M7.2,8.2 c0.5,0 0.8,0.4 0.8,0.8 s-0.4,0.8 -0.8,0.8 -0.8,-0.4 -0.8,-0.8 0.4,-0.8 0.8,-0.8 Z M11.4,8.2 c0.5,0 0.8,0.4 0.8,0.8 s-0.4,0.8 -0.8,0.8 -0.8,-0.4 -0.8,-0.8 0.4,-0.8 0.8,-0.8 Z M15.5,9 c-3.2,0 -5.7,2.1 -5.7,4.6 0,2.6 2.6,4.6 5.7,4.6 0.7,0 1.4,-0.1 2,-0.3 l2.1,1.1 -0.6,-1.8 c1.5,-0.9 2.5,-2.3 2.5,-3.9 C21.5,11 18.7,9 15.5,9 Z M13.6,12 c0.4,0 0.7,0.3 0.7,0.7 s-0.3,0.7 -0.7,0.7 -0.7,-0.3 -0.7,-0.7 0.3,-0.7 0.7,-0.7 Z M17.4,12 c0.4,0 0.7,0.3 0.7,0.7 s-0.3,0.7 -0.7,0.7 -0.7,-0.3 -0.7,-0.7 0.3,-0.7 0.7,-0.7 Z"/></svg>
            </button>
            <button type="button" title="QQ" @click="onSocial('QQ')">
              <svg viewBox="0 0 24 24" fill="#a37f3d"><path d="M12,2 C8.2,2 5.2,5.1 5.2,9 c0,1.2 0.2,2.3 0.6,3.3 C5,13.6 4.2,15.4 4.2,16.4 c0,0.6 0.5,0.8 1,0.4 0.5,-0.3 1.1,-0.9 1.6,-1.4 0.2,0.3 0.4,0.5 0.7,0.8 C6.6,17 6.2,18 6.2,18.6 c0,0.5 0.4,0.6 0.9,0.3 0.6,-0.4 1.3,-1.1 1.8,-1.7 0.9,0.2 1.9,0.3 3.1,0.3 s2.2,-0.1 3.1,-0.3 c0.5,0.6 1.2,1.3 1.8,1.7 0.5,0.3 0.9,0.2 0.9,-0.3 0,-0.6 -0.4,-1.6 -1.3,-2.4 0.3,-0.3 0.5,-0.5 0.7,-0.8 0.5,0.5 1.1,1.1 1.6,1.4 0.5,0.4 1,0.2 1,-0.4 0,-1 -0.8,-2.8 -1.6,-4.1 0.4,-1 0.6,-2.1 0.6,-3.3 C18.8,5.1 15.8,2 12,2 Z"/></svg>
            </button>
            <button type="button" title="邮箱" @click="onSocial('邮箱')">
              <svg viewBox="0 0 24 24" fill="none" stroke="#b3362b" stroke-width="1.8">
                <rect x="3" y="6" width="18" height="13" rx="2" /><path d="M3,8 L12,14 L21,8" />
              </svg>
            </button>
          </div>

          <p class="foot">
            <template v-if="mode === 'login'">
              尚无账号？<a href="#" class="link" @click.prevent="switchMode('register')"><b>立即注册</b></a>
            </template>
            <template v-else>
              已有账号？<a href="#" class="link" @click.prevent="switchMode('login')"><b>去登录</b></a>
            </template>
          </p>
        </div>
      </div>
    </div>

    <!-- 底部落款 -->
    <div class="login-footer">离恨烟 © 烟雨阁</div>
  </section>
</template>

<style scoped>
/* ===========================================================
   登录页 · 立绘分栏布局（参考 lihengyan-login/index.html）
   卡片、表单、验证码等样式沿用全局 ink.css
   =========================================================== */

.login-stage {
  position: relative;
  height: 100vh;
  overflow: hidden;
}

/* 飘浮烟雾 */
.login-mist {
  position: absolute;
  border-radius: 50%;
  filter: blur(60px);
  opacity: 0.35;
  z-index: 1;
  pointer-events: none;
  animation: mist-drift 18s ease-in-out infinite alternate;
}

.login-mist.m1 {
  width: 520px;
  height: 520px;
  background: #a9cdc5;
  top: -120px;
  left: -120px;
}

.login-mist.m2 {
  width: 420px;
  height: 420px;
  background: #bcd8d1;
  bottom: -140px;
  right: 26%;
  animation-delay: -6s;
}

.login-mist.m3 {
  width: 300px;
  height: 300px;
  background: #e6d9bd;
  top: 30%;
  right: -100px;
  animation-delay: -12s;
  opacity: 0.25;
}

@keyframes mist-drift {
  from {
    transform: translate(0, 0) scale(1);
  }
  to {
    transform: translate(60px, 30px) scale(1.12);
  }
}

/* 主布局：左立绘 / 右登录卡 */
.stage {
  position: relative;
  z-index: 2;
  height: 100%;
  display: flex;
  align-items: stretch;
}

/* 左侧立绘 */
.portrait {
  position: relative;
  flex: 1.15;
  min-width: 0;
  display: flex;
  align-items: flex-end;
  justify-content: center;
}

.portrait::before {
  content: '';
  position: absolute;
  inset: 0;
  background: radial-gradient(
    ellipse 70% 90% at 50% 45%,
    rgba(244, 241, 232, 0) 40%,
    rgba(207, 227, 222, 0.55) 100%
  );
  z-index: 2;
  pointer-events: none;
}

.portrait img {
  height: 100%;
  width: 100%;
  object-fit: cover;
  object-position: center 20%;
  -webkit-mask-image: linear-gradient(
    to right,
    rgba(0, 0, 0, 0) 0%,
    rgba(0, 0, 0, 0.25) 6%,
    #000 18%,
    #000 82%,
    rgba(0, 0, 0, 0.55) 94%,
    rgba(0, 0, 0, 0) 100%
  );
  mask-image: linear-gradient(
    to right,
    rgba(0, 0, 0, 0) 0%,
    rgba(0, 0, 0, 0.25) 6%,
    #000 18%,
    #000 82%,
    rgba(0, 0, 0, 0.55) 94%,
    rgba(0, 0, 0, 0) 100%
  );
  filter: saturate(1.05);
  animation: portrait-in 1.6s cubic-bezier(0.22, 0.8, 0.3, 1) both;
}

@keyframes portrait-in {
  from {
    opacity: 0;
    transform: scale(1.06) translateY(20px);
    filter: saturate(0.4) blur(6px);
  }
  to {
    opacity: 1;
    transform: scale(1) translateY(0);
    filter: saturate(1.05) blur(0);
  }
}

/* 竖排诗题 */
.verse {
  position: absolute;
  left: 42px;
  top: 50%;
  transform: translateY(-50%);
  writing-mode: vertical-rl;
  z-index: 3;
  font-size: 22px;
  letter-spacing: 14px;
  color: var(--ink-soft);
  opacity: 0.75;
  user-select: none;
  animation: verse-fade 1.8s 0.4s both;
}

.verse b {
  color: var(--cinnabar);
  font-weight: normal;
}

@keyframes verse-fade {
  from {
    opacity: 0;
    transform: translateY(calc(-50% + 16px));
  }
  to {
    opacity: 0.75;
    transform: translateY(-50%);
  }
}

/* 右侧登录区 */
.panel {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 40px;
  position: relative;
}

/* 卡片进场动画（全局 .card 样式之外的补充） */
.card {
  animation: card-in 1.2s 0.3s cubic-bezier(0.22, 0.8, 0.3, 1) both;
}

@keyframes card-in {
  from {
    opacity: 0;
    transform: translateY(36px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

/* 抖动动画优先于进场动画 */
.card.shake {
  animation: card-shake 0.4s;
}

/* 表单字段右侧 SVG 图标 */
.field .ico {
  position: absolute;
  right: 4px;
  bottom: 9px;
  width: 20px;
  height: 20px;
  opacity: 0.55;
  pointer-events: none;
}

/* 第三方登录 SVG 图标尺寸 */
.social button svg {
  width: 20px;
  height: 20px;
}

/* 底部落款 */
.login-footer {
  position: absolute;
  bottom: 18px;
  right: 26px;
  z-index: 3;
  font-size: 12px;
  letter-spacing: 3px;
  color: rgba(61, 80, 75, 0.5);
}

/* 窄屏：隐藏立绘与诗题，仅保留登录卡 */
@media (max-width: 900px) {
  .portrait {
    display: none;
  }
  .panel {
    flex: 1;
  }
}
</style>
