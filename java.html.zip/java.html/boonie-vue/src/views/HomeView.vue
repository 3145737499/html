<script setup>
/**
 * 个人中心 · 离恨烟 · 伞下江湖
 * 由 user store 驱动问候语
 */
import { ref } from 'vue'

import { useUserStore } from '@/stores/user'
import { useReveal } from '@/composables/useReveal'

const user = useUserStore()

const root = ref(null)
useReveal(root)

const copy = {
  sub: '今日烟雨正好，伞下自有江湖 🌂',
  tiles: [
    { ic: '🌂', title: '我的油纸伞', desc: '查看你的纸伞与伞面丹青进度。' },
    { ic: '🏅', title: '江湖徽章', desc: '已收集 12 枚，继续行侠解锁更多。' },
    { ic: '📖', title: '行侠日志', desc: '记录每一次伞下奇遇与山水相逢。' },
    { ic: '⚙️', title: '账号设置', desc: '管理名号、密码与登录方式。' },
  ],
}
</script>

<template>
  <section ref="root" class="view home active">
    <div class="home">
      <div class="welcome reveal">
        <div class="ava">🌂</div>
        <div>
          <h2>{{ user.greeting }}</h2>
          <p>{{ copy.sub }}</p>
        </div>
      </div>

      <div class="grid">
        <div v-for="tile in copy.tiles" :key="tile.title" class="tile reveal">
          <div class="ic">{{ tile.ic }}</div>
          <h3>{{ tile.title }}</h3>
          <p>{{ tile.desc }}</p>
        </div>
      </div>
    </div>
  </section>
</template>
