/**
 * 认证 API 层
 * 对接 Spring Boot 后端（/api/auth/*，开发环境经 Vite 代理转发到 http://localhost:9090）
 * 统一返回结构：{ success, message, token, data }
 */

const BASE = '/api/auth'

async function post(path, body = {}) {
  const res = await fetch(`${BASE}${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  })
  if (!res.ok) {
    // 网络层 / 服务端 5xx 等异常
    return { success: false, message: `服务异常（HTTP ${res.status}），请稍后再试` }
  }
  return res.json()
}

/** 发送注册验证码：{ account } -> { success, message, data: 验证码(演示模式) } */
export function sendCode(account) {
  return post('/send-code', { account })
}

/** 注册：{ account, password, code } -> { success, token, message } */
export function register(account, password, code) {
  return post('/register', { account, password, code })
}

/** 登录：{ account, password } -> { success, token, message, data: account } */
export function login(account, password) {
  return post('/login', { account, password })
}

/** 登出：{ token } -> { success, message } */
export function logout(token) {
  return post('/logout', { token })
}
