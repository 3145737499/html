<script setup>
/**
 * 水墨背景层
 * 远山淡影 + 墨笔横划 + 三团飘浮烟雾
 */
</script>

<template>
  <div class="ink-bg" aria-hidden="true">
    <svg viewBox="0 0 1440 900" preserveAspectRatio="xMidYMid slice">
      <defs>
        <radialGradient id="inkG" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stop-color="#3d504b" stop-opacity=".28" />
          <stop offset="100%" stop-color="#3d504b" stop-opacity="0" />
        </radialGradient>
        <linearGradient id="mtn" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="#7fa8a0" stop-opacity=".35" />
          <stop offset="100%" stop-color="#7fa8a0" stop-opacity="0" />
        </linearGradient>
      </defs>

      <ellipse cx="180" cy="820" rx="340" ry="130" fill="url(#inkG)" />
      <ellipse cx="1300" cy="120" rx="300" ry="110" fill="url(#inkG)" />

      <!-- 远山两叠 -->
      <path d="M-40,700 Q180,540 380,660 T760,620 T1140,680 T1500,600 L1500,900 L-40,900 Z" fill="url(#mtn)" />
      <path d="M-40,760 Q260,640 520,730 T1080,700 T1500,740 L1500,900 L-40,900 Z" fill="url(#mtn)" opacity=".7" />

      <!-- 墨笔横划 -->
      <path d="M60,120 Q400,86 760,108 T1380,92" stroke="#2c423d" stroke-opacity=".14" stroke-width="7" fill="none" stroke-linecap="round" />
      <path d="M120,146 Q460,120 820,140" stroke="#2c423d" stroke-opacity=".09" stroke-width="4" fill="none" stroke-linecap="round" />
    </svg>

    <!-- 飘浮烟雾 -->
    <div class="mist m1"></div>
    <div class="mist m2"></div>
    <div class="mist m3"></div>
  </div>
</template>

<style scoped>
.ink-bg {
  position: fixed;
  inset: 0;
  z-index: 0;
  pointer-events: none;
}

.ink-bg svg {
  width: 100%;
  height: 100%;
}

.mist {
  position: fixed;
  border-radius: 50%;
  filter: blur(60px);
  opacity: 0.35;
  pointer-events: none;
  animation: drift 18s ease-in-out infinite alternate;
}

.mist.m1 {
  width: 520px;
  height: 520px;
  background: #a9cdc5;
  top: -120px;
  left: -120px;
}

.mist.m2 {
  width: 420px;
  height: 420px;
  background: #bcd8d1;
  bottom: -140px;
  right: 26%;
  animation-delay: -6s;
}

.mist.m3 {
  width: 300px;
  height: 300px;
  background: #e6d9bd;
  top: 30%;
  right: -100px;
  animation-delay: -12s;
  opacity: 0.25;
}

@keyframes drift {
  from {
    transform: translate(0, 0) scale(1);
  }
  to {
    transform: translate(60px, 30px) scale(1.12);
  }
}
</style>
