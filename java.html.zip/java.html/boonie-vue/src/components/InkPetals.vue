<script setup>
/**
 * 飘落的花瓣 / 墨点
 * 朱红 / 鎏金 / 青绿三色，随机大小与落速
 */
import { onBeforeUnmount, onMounted } from 'vue'

const COLORS = ['#b3362b', '#c9a35c', '#4e8d86']
let petals = []

onMounted(() => {
  for (let i = 0; i < 12; i++) {
    const p = document.createElement('div')
    p.className = 'petal'
    const size = 6 + Math.random() * 8
    const c = COLORS[Math.floor(Math.random() * COLORS.length)]
    p.style.cssText = [
      `left:${Math.random() * 100}vw`,
      `width:${size}px`,
      `height:${size * 0.7}px`,
      `background:${c}`,
      `opacity:${0.35 + Math.random() * 0.4}`,
      `animation-duration:${9 + Math.random() * 10}s`,
      `animation-delay:${-Math.random() * 12}s`,
    ].join(';')
    document.body.appendChild(p)
    petals.push(p)
  }
})

onBeforeUnmount(() => {
  petals.forEach((p) => p.remove())
  petals = []
})
</script>

<template></template>
